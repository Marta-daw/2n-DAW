<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    protected $fillable = [
        'titol',
        'contingut',
        'user_id'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
