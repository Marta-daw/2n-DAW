# Code Rolls The Dice - Guia Pas per Pas
## Creació d'un Personatge D&D amb Django

---

## 📋 Índex
1. [Preparació de l'Entorn](#1-preparació-de-lentorn)
2. [Versió 1: Creació Manual](#2-versió-1-creació-manual)
3. [Versió 2: Generació Aleatòria](#3-versió-2-generació-aleatòria)
4. [Estructura de Fitxers](#4-estructura-de-fitxers)
5. [Proves i Validació](#5-proves-i-validació)

---

## 1. Preparació de l'Entorn

### 1.1. Instal·lació de Django
```bash
# Crear un entorn virtual
python -m venv venv

# Activar l'entorn virtual
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Instal·lar Django
pip install django
```

### 1.2. Crear el Projecte Django
```bash
# Crear el projecte principal
django-admin startproject dnd_project

# Entrar al directori del projecte
cd dnd_project

# Crear l'aplicació de personatges
python manage.py startapp personatges
```

### 1.3. Configurar l'Aplicació
Edita `dnd_project/settings.py` i afegeix l'aplicació:

```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'personatges',  # ← Afegir aquesta línia
]
```

---

## 2. Versió 1: Creació Manual

### 2.1. Model del Personatge (`personatges/models.py`)

**📍 Fitxer:** `personatges/models.py`

```python
from django.db import models

class Personatge(models.Model):
    """Model que representa un personatge de D&D"""
    
    # Opcions de raça
    RACES = [
        ('huma', 'Humà'),
        ('elf', 'Elf'),
        ('nan', 'Nan'),
        ('halfling', 'Halfling'),
        ('drac', 'Dracònic'),
        ('orc', 'Orc'),
    ]
    
    # Opcions de classe
    CLASSES = [
        ('guerrer', 'Guerrer'),
        ('mag', 'Mag'),
        ('clergue', 'Clergue'),
        ('lladre', 'Lladre'),
        ('ranger', 'Ranger'),
        ('bard', 'Bard'),
    ]
    
    # Camps del personatge
    nom = models.CharField(max_length=100, verbose_name="Nom del Personatge")
    raca = models.CharField(max_length=20, choices=RACES, verbose_name="Raça")
    classe = models.CharField(max_length=20, choices=CLASSES, verbose_name="Classe")
    
    # Estadístiques (valors entre 3 i 18)
    forca = models.IntegerField(verbose_name="Força")
    destresa = models.IntegerField(verbose_name="Destresa")
    constitucio = models.IntegerField(verbose_name="Constitució")
    intelligencia = models.IntegerField(verbose_name="Intel·ligència")
    saviesa = models.IntegerField(verbose_name="Saviesa")
    carisma = models.IntegerField(verbose_name="Carisma")
    
    # Metadades
    creat_el = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.nom} - {self.get_raca_display()} {self.get_classe_display()}"
    
    class Meta:
        verbose_name = "Personatge"
        verbose_name_plural = "Personatges"
        ordering = ['-creat_el']
```

**🎯 Què fa aquest codi:**
- Defineix el model `Personatge` amb tots els camps necessaris
- Inclou opcions per raça i classe
- Les estadístiques són camps d'enters (3-18 típicament en D&D)
- Guarda la data de creació automàticament

---

### 2.2. Formulari Manual (`personatges/forms.py`)

**📍 Fitxer:** `personatges/forms.py`

```python
from django import forms
from .models import Personatge

class PersonatgeForm(forms.ModelForm):
    """Formulari per crear un personatge manualment"""
    
    class Meta:
        model = Personatge
        fields = ['nom', 'raca', 'classe', 'forca', 'destresa', 
                  'constitucio', 'intelligencia', 'saviesa', 'carisma']
        
        widgets = {
            'nom': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Introdueix el nom del personatge'
            }),
            'raca': forms.Select(attrs={'class': 'form-control'}),
            'classe': forms.Select(attrs={'class': 'form-control'}),
            'forca': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'destresa': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'constitucio': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'intelligencia': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'saviesa': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'carisma': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
        }
    
    def clean(self):
        """Validació personalitzada"""
        cleaned_data = super().clean()
        
        # Validar que les estadístiques estiguin entre 3 i 18
        stats = ['forca', 'destresa', 'constitucio', 
                 'intelligencia', 'saviesa', 'carisma']
        
        for stat in stats:
            value = cleaned_data.get(stat)
            if value and (value < 3 or value > 18):
                self.add_error(stat, 'El valor ha d\'estar entre 3 i 18')
        
        return cleaned_data
```

**🎯 Què fa aquest codi:**
- Crea un formulari basat en el model `Personatge`
- Afegeix classes CSS de Bootstrap per estilitzar
- Defineix valors mínims i màxims (3-18) per les estadístiques
- Inclou validació personalitzada

---

### 2.3. Vista per Processar el Formulari (`personatges/views.py`)

**📍 Fitxer:** `personatges/views.py`

```python
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Personatge
from .forms import PersonatgeForm

def crear_personatge(request):
    """Vista per crear un personatge manualment"""
    
    if request.method == 'POST':
        form = PersonatgeForm(request.POST)
        
        if form.is_valid():
            personatge = form.save()
            messages.success(request, f'Personatge "{personatge.nom}" creat correctament!')
            return redirect('llista_personatges')
    else:
        form = PersonatgeForm()
    
    return render(request, 'personatges/crear_personatge.html', {
        'form': form,
        'titol': 'Crear Personatge Manual'
    })


def llista_personatges(request):
    """Vista per mostrar tots els personatges"""
    personatges = Personatge.objects.all()
    
    return render(request, 'personatges/llista_personatges.html', {
        'personatges': personatges
    })
```

**🎯 Què fa aquest codi:**
- `crear_personatge`: Processa el formulari i desa el personatge
- `llista_personatges`: Mostra tots els personatges creats
- Afegeix missatges d'èxit quan es crea un personatge

---

### 2.4. URLs (`personatges/urls.py`)

**📍 Fitxer:** `personatges/urls.py` (CREAR-LO)

```python
from django.urls import path
from . import views

urlpatterns = [
    path('', views.llista_personatges, name='llista_personatges'),
    path('crear/', views.crear_personatge, name='crear_personatge'),
]
```

**Afegir a `dnd_project/urls.py`:**

```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('personatges/', include('personatges.urls')),
]
```

---

### 2.5. Templates HTML

**📍 Crear estructura:** `personatges/templates/personatges/`

#### Base Template (`base.html`)

```html
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Code Rolls The Dice{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .stat-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">🎲 Code Rolls The Dice 🎲</h1>
        
        {% if messages %}
            {% for message in messages %}
                <div class="alert alert-{{ message.tags }} alert-dismissible fade show" role="alert">
                    {{ message }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            {% endfor %}
        {% endif %}
        
        {% block content %}{% endblock %}
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
```

#### Formulari de Creació (`crear_personatge.html`)

```html
{% extends 'personatges/base.html' %}

{% block title %}{{ titol }}{% endblock %}

{% block content %}
<h2 class="mb-4">{{ titol }}</h2>

<form method="post" class="needs-validation" novalidate>
    {% csrf_token %}
    
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="id_nom" class="form-label">Nom del Personatge</label>
            {{ form.nom }}
            {% if form.nom.errors %}
                <div class="text-danger">{{ form.nom.errors }}</div>
            {% endif %}
        </div>
        
        <div class="col-md-3 mb-3">
            <label for="id_raca" class="form-label">Raça</label>
            {{ form.raca }}
            {% if form.raca.errors %}
                <div class="text-danger">{{ form.raca.errors }}</div>
            {% endif %}
        </div>
        
        <div class="col-md-3 mb-3">
            <label for="id_classe" class="form-label">Classe</label>
            {{ form.classe }}
            {% if form.classe.errors %}
                <div class="text-danger">{{ form.classe.errors }}</div>
            {% endif %}
        </div>
    </div>
    
    <h4 class="mt-4 mb-3">Estadístiques (3-18)</h4>
    
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <label for="id_forca" class="form-label">💪 Força</label>
                {{ form.forca }}
                {% if form.forca.errors %}
                    <div class="text-danger">{{ form.forca.errors }}</div>
                {% endif %}
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <label for="id_destresa" class="form-label">🏹 Destresa</label>
                {{ form.destresa }}
                {% if form.destresa.errors %}
                    <div class="text-danger">{{ form.destresa.errors }}</div>
                {% endif %}
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <label for="id_constitucio" class="form-label">❤️ Constitució</label>
                {{ form.constitucio }}
                {% if form.constitucio.errors %}
                    <div class="text-danger">{{ form.constitucio.errors }}</div>
                {% endif %}
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <label for="id_intelligencia" class="form-label">🧠 Intel·ligència</label>
                {{ form.intelligencia }}
                {% if form.intelligencia.errors %}
                    <div class="text-danger">{{ form.intelligencia.errors }}</div>
                {% endif %}
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <label for="id_saviesa" class="form-label">🦉 Saviesa</label>
                {{ form.saviesa }}
                {% if form.saviesa.errors %}
                    <div class="text-danger">{{ form.saviesa.errors }}</div>
                {% endif %}
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <label for="id_carisma" class="form-label">✨ Carisma</label>
                {{ form.carisma }}
                {% if form.carisma.errors %}
                    <div class="text-danger">{{ form.carisma.errors }}</div>
                {% endif %}
            </div>
        </div>
    </div>
    
    <div class="text-center mt-4">
        <button type="submit" class="btn btn-primary btn-lg">Crear Personatge</button>
        <a href="{% url 'llista_personatges' %}" class="btn btn-secondary btn-lg">Cancel·lar</a>
    </div>
</form>
{% endblock %}
```

#### Llista de Personatges (`llista_personatges.html`)

```html
{% extends 'personatges/base.html' %}

{% block title %}Llista de Personatges{% endblock %}

{% block content %}
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Personatges Creats</h2>
    <a href="{% url 'crear_personatge' %}" class="btn btn-primary">➕ Nou Personatge</a>
</div>

{% if personatges %}
    <div class="row">
        {% for personatge in personatges %}
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">{{ personatge.nom }}</h5>
                </div>
                <div class="card-body">
                    <p><strong>Raça:</strong> {{ personatge.get_raca_display }}</p>
                    <p><strong>Classe:</strong> {{ personatge.get_classe_display }}</p>
                    
                    <h6 class="mt-3">Estadístiques:</h6>
                    <div class="row">
                        <div class="col-4">
                            <small>💪 Força:</small> <strong>{{ personatge.forca }}</strong>
                        </div>
                        <div class="col-4">
                            <small>🏹 Destresa:</small> <strong>{{ personatge.destresa }}</strong>
                        </div>
                        <div class="col-4">
                            <small>❤️ Constitució:</small> <strong>{{ personatge.constitucio }}</strong>
                        </div>
                        <div class="col-4">
                            <small>🧠 Intel·ligència:</small> <strong>{{ personatge.intelligencia }}</strong>
                        </div>
                        <div class="col-4">
                            <small>🦉 Saviesa:</small> <strong>{{ personatge.saviesa }}</strong>
                        </div>
                        <div class="col-4">
                            <small>✨ Carisma:</small> <strong>{{ personatge.carisma }}</strong>
                        </div>
                    </div>
                    
                    <p class="text-muted mt-3 mb-0">
                        <small>Creat: {{ personatge.creat_el|date:"d/m/Y H:i" }}</small>
                    </p>
                </div>
            </div>
        </div>
        {% endfor %}
    </div>
{% else %}
    <div class="alert alert-info text-center">
        <p class="mb-0">Encara no hi ha personatges creats. 
        <a href="{% url 'crear_personatge' %}">Crea'n un ara!</a></p>
    </div>
{% endif %}
{% endblock %}
```

---

### 2.6. Executar Migracions i Servidor

```bash
# Crear les migracions
python manage.py makemigrations

# Aplicar les migracions
python manage.py migrate

# Crear un superusuari (opcional, per accedir a l'admin)
python manage.py createsuperuser

# Executar el servidor
python manage.py runserver
```

**🌐 Accedir a l'aplicació:**
- Llista de personatges: http://127.0.0.1:8000/personatges/
- Crear personatge: http://127.0.0.1:8000/personatges/crear/

---

## 3. Versió 2: Generació Aleatòria

### 3.1. Afegir Funció `roll_stat` al Model

**📍 Modificar:** `personatges/models.py`

```python
from django.db import models
import random

class Personatge(models.Model):
    """Model que representa un personatge de D&D"""
    
    # ... (tot el codi anterior es manté igual)
    
    @staticmethod
    def roll_stat():
        """
        Simula la tirada de 4d6 i descarta el valor més baix.
        Retorna un valor entre 3 i 18 (típicament entre 8 i 16).
        """
        # Tirar 4 daus de 6 cares
        rolls = [random.randint(1, 6) for _ in range(4)]
        
        # Eliminar el valor més baix
        rolls.remove(min(rolls))
        
        # Sumar els 3 valors restants
        return sum(rolls)
    
    @classmethod
    def crear_aleatori(cls, nom, raca, classe):
        """Crea un personatge amb estadístiques aleatòries"""
        return cls.objects.create(
            nom=nom,
            raca=raca,
            classe=classe,
            forca=cls.roll_stat(),
            destresa=cls.roll_stat(),
            constitucio=cls.roll_stat(),
            intelligencia=cls.roll_stat(),
            saviesa=cls.roll_stat(),
            carisma=cls.roll_stat(),
        )
```

**🎯 Què fa aquest codi:**
- `roll_stat()`: Tira 4d6, descarta el més baix, suma els altres 3
- `crear_aleatori()`: Crea un personatge amb stats generades automàticament

---

### 3.2. Afegir Checkbox "Randomize" al Formulari

**📍 Modificar:** `personatges/forms.py`

```python
from django import forms
from .models import Personatge

class PersonatgeForm(forms.ModelForm):
    """Formulari per crear un personatge amb opció d'aleatorietat"""
    
    randomize = forms.BooleanField(
        required=False,
        label="🎲 Generar Màgicament",
        help_text="Marca aquesta opció per generar les estadístiques automàticament (4d6)",
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input',
            'id': 'randomize-checkbox'
        })
    )
    
    class Meta:
        model = Personatge
        fields = ['nom', 'raca', 'classe', 'forca', 'destresa', 
                  'constitucio', 'intelligencia', 'saviesa', 'carisma']
        
        widgets = {
            'nom': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Introdueix el nom del personatge'
            }),
            'raca': forms.Select(attrs={'class': 'form-control'}),
            'classe': forms.Select(attrs={'class': 'form-control'}),
            'forca': forms.NumberInput(attrs={
                'class': 'form-control stat-input',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'destresa': forms.NumberInput(attrs={
                'class': 'form-control stat-input',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'constitucio': forms.NumberInput(attrs={
                'class': 'form-control stat-input',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'intelligencia': forms.NumberInput(attrs={
                'class': 'form-control stat-input',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'saviesa': forms.NumberInput(attrs={
                'class': 'form-control stat-input',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
            'carisma': forms.NumberInput(attrs={
                'class': 'form-control stat-input',
                'min': 3,
                'max': 18,
                'placeholder': '3-18'
            }),
        }
    
    def clean(self):
        """Validació personalitzada"""
        cleaned_data = super().clean()
        randomize = cleaned_data.get('randomize')
        
        # Si randomize està activat, no validem les estadístiques
        # perquè es generaran automàticament
        if not randomize:
            stats = ['forca', 'destresa', 'constitucio', 
                     'intelligencia', 'saviesa', 'carisma']
            
            for stat in stats:
                value = cleaned_data.get(stat)
                if value is None:
                    self.add_error(stat, 'Aquest camp és obligatori')
                elif value < 3 or value > 18:
                    self.add_error(stat, 'El valor ha d\'estar entre 3 i 18')
        
        return cleaned_data
```

**🎯 Què fa aquest codi:**
- Afegeix un camp checkbox `randomize`
- Si està marcat, no valida les estadístiques (es generaran després)
- Afegeix la classe CSS `stat-input` per poder amagar/mostrar camps

---

### 3.3. Modificar la Vista per Gestionar l'Aleatorietat

**📍 Modificar:** `personatges/views.py`

```python
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Personatge
from .forms import PersonatgeForm

def crear_personatge(request):
    """Vista per crear un personatge amb opció d'aleatorietat"""
    
    if request.method == 'POST':
        form = PersonatgeForm(request.POST)
        
        if form.is_valid():
            randomize = form.cleaned_data.get('randomize')
            
            if randomize:
                # Generar personatge amb estadístiques aleatòries
                personatge = Personatge.crear_aleatori(
                    nom=form.cleaned_data['nom'],
                    raca=form.cleaned_data['raca'],
                    classe=form.cleaned_data['classe']
                )
                messages.success(
                    request, 
                    f'✨ Personatge "{personatge.nom}" creat màgicament amb estadístiques aleatòries!'
                )
            else:
                # Desar amb les estadístiques introduïdes manualment
                personatge = form.save()
                messages.success(
                    request, 
                    f'✅ Personatge "{personatge.nom}" creat manualment!'
                )
            
            return redirect('llista_personatges')
    else:
        form = PersonatgeForm()
    
    return render(request, 'personatges/crear_personatge.html', {
        'form': form,
        'titol': 'Crear Personatge'
    })


def llista_personatges(request):
    """Vista per mostrar tots els personatges"""
    personatges = Personatge.objects.all()
    
    return render(request, 'personatges/llista_personatges.html', {
        'personatges': personatges
    })
```

**🎯 Què fa aquest codi:**
- Comprova si el checkbox `randomize` està marcat
- Si està marcat: usa `crear_aleatori()` i ignora les estadístiques del formulari
- Si no està marcat: desa les estadístiques introduïdes manualment

---

### 3.4. Actualitzar el Template amb JavaScript

**📍 Modificar:** `personatges/templates/personatges/crear_personatge.html`

Afegir ABANS del formulari:

```html
{% block content %}
<h2 class="mb-4">{{ titol }}</h2>

<div class="alert alert-info">
    <strong>💡 Consell:</strong> Pots introduir les estadístiques manualment o marcar 
    "Generar Màgicament" per que es creïn automàticament amb el mètode 4d6 (tira 4 daus de 6 cares i descarta el més baix).
</div>

<form method="post" class="needs-validation" novalidate>
    {% csrf_token %}
    
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="id_nom" class="form-label">Nom del Personatge</label>
            {{ form.nom }}
            {% if form.nom.errors %}
                <div class="text-danger">{{ form.nom.errors }}</div>
            {% endif %}
        </div>
        
        <div class="col-md-3 mb-3">
            <label for="id_raca" class="form-label">Raça</label>
            {{ form.raca }}
            {% if form.raca.errors %}
                <div class="text-danger">{{ form.raca.errors }}</div>
            {% endif %}
        </div>
        
        <div class="col-md-3 mb-3">
            <label for="id_classe" class="form-label">Classe</label>
            {{ form.classe }}
            {% if form.classe.errors %}
                <div class="text-danger">{{ form.classe.errors }}</div>
            {% endif %}
        </div>
    </div>
    
    <!-- CHECKBOX DE RANDOMIZE -->
    <div class="form-check mb-4 p-3 bg-light rounded">
        {{ form.randomize }}
        <label class="form-check-label" for="randomize-checkbox">
            <strong>{{ form.randomize.label }}</strong>
            <br>
            <small class="text-muted">{{ form.randomize.help_text }}</small>
        </label>
    </div>
    
    <h4 class="mt-4 mb-3">Estadístiques (3-18)</h4>
    <div id="stats-container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="stat-box">
                    <label for="id_forca" class="form-label">💪 Força</label>
                    {{ form.forca }}
                    {% if form.forca.errors %}
                        <div class="text-danger">{{ form.forca.errors }}</div>
                    {% endif %}
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="stat-box">
                    <label for="id_destresa" class="form-label">🏹 Destresa</label>
                    {{ form.destresa }}
                    {% if form.destresa.errors %}
                        <div class="text-danger">{{ form.destresa.errors }}</div>
                    {% endif %}
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="stat-box">
                    <label for="id_constitucio" class="form-label">❤️ Constitució</label>
                    {{ form.constitucio }}
                    {% if form.constitucio.errors %}
                        <div class="text-danger">{{ form.constitucio.errors }}</div>
                    {% endif %}
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="stat-box">
                    <label for="id_intelligencia" class="form-label">🧠 Intel·ligència</label>
                    {{ form.intelligencia }}
                    {% if form.intelligencia.errors %}
                        <div class="text-danger">{{ form.intelligencia.errors }}</div>
                    {% endif %}
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="stat-box">
                    <label for="id_saviesa" class="form-label">🦉 Saviesa</label>
                    {{ form.saviesa }}
                    {% if form.saviesa.errors %}
                        <div class="text-danger">{{ form.saviesa.errors }}</div>
                    {% endif %}
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="stat-box">
                    <label for="id_carisma" class="form-label">✨ Carisma</label>
                    {{ form.carisma }}
                    {% if form.carisma.errors %}
                        <div class="text-danger">{{ form.carisma.errors }}</div>
                    {% endif %}
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-4">
        <button type="submit" class="btn btn-primary btn-lg">Crear Personatge</button>
        <a href="{% url 'llista_personatges' %}" class="btn btn-secondary btn-lg">Cancel·lar</a>
    </div>
</form>

<script>
    // JavaScript per amagar/mostrar els camps d'estadístiques
    document.addEventListener('DOMContentLoaded', function() {
        const randomizeCheckbox = document.getElementById('randomize-checkbox');
        const statsContainer = document.getElementById('stats-container');
        const statInputs = document.querySelectorAll('.stat-input');
        
        function toggleStats() {
            if (randomizeCheckbox.checked) {
                // Amagar i deshabilitar camps d'estadístiques
                statsContainer.style.opacity = '0.5';
                statInputs.forEach(input => {
                    input.disabled = true;
                    input.value = '';
                });
            } else {
                // Mostrar i habilitar camps d'estadístiques
                statsContainer.style.opacity = '1';
                statInputs.forEach(input => {
                    input.disabled = false;
                });
            }
        }
        
        // Executar al carregar la pàgina
        toggleStats();
        
        // Executar quan canviï el checkbox
        randomizeCheckbox.addEventListener('change', toggleStats);
    });
</script>
{% endblock %}
```

**🎯 Què fa aquest codi:**
- Afegeix el checkbox "Generar Màgicament" amb una descripció
- Afegeix JavaScript per amagar/deshabilitar els camps d'estadístiques quan el checkbox està marcat
- Millora l'experiència d'usuari mostrant visualment què està activat

---

## 4. Estructura de Fitxers

```
dnd_project/
│
├── dnd_project/              # Configuració del projecte
│   ├── __init__.py
│   ├── settings.py          # ← Afegir 'personatges' a INSTALLED_APPS
│   ├── urls.py              # ← Afegir include('personatges.urls')
│   ├── asgi.py
│   └── wsgi.py
│
├── personatges/              # Aplicació principal
│   ├── migrations/          # Migracions de la base de dades
│   │   └── __init__.py
│   │
│   ├── templates/
│   │   └── personatges/
│   │       ├── base.html                 # Template base
│   │       ├── crear_personatge.html     # Formulari de creació
│   │       └── llista_personatges.html   # Llista de personatges
│   │
│   ├── __init__.py
│   ├── admin.py             # Admin de Django
│   ├── apps.py
│   ├── models.py            # ✅ Model Personatge + roll_stat()
│   ├── forms.py             # ✅ Formulari + checkbox randomize
│   ├── views.py             # ✅ Vistes + lògica de randomize
│   ├── urls.py              # ✅ CREAR - Rutes de l'app
│   └── tests.py             # Tests unitaris
│
├── db.sqlite3               # Base de dades
├── manage.py                # Script de gestió de Django
└── requirements.txt         # Dependències (Django)
```

---

## 5. Proves i Validació

### 5.1. Proves Manuals

**Test 1: Creació Manual**
1. Anar a http://127.0.0.1:8000/personatges/crear/
2. Introduir: Nom="Thorin", Raça="Nan", Classe="Guerrer"
3. Introduir estadístiques manualment (p.ex. tots 15)
4. Verificar que es crea correctament

**Test 2: Creació Aleatòria**
1. Anar a http://127.0.0.1:8000/personatges/crear/
2. Introduir: Nom="Gandalf", Raça="Elf", Classe="Mag"
3. ✅ Marcar "Generar Màgicament"
4. Verificar que els camps d'estadístiques es deshabiliten
5. Crear i verificar que les estadístiques són diferents cada vegada

**Test 3: Validació**
1. Intentar crear sense nom → Ha de mostrar error
2. Intentar posar estadística = 2 (manual) → Ha de mostrar error
3. Intentar posar estadística = 20 (manual) → Ha de mostrar error

---

### 5.2. Tests Unitaris

**📍 Crear:** `personatges/tests.py`

```python
from django.test import TestCase
from .models import Personatge

class PersonatgeModelTests(TestCase):
    
    def test_roll_stat_range(self):
        """Verificar que roll_stat retorna valors entre 3 i 18"""
        for _ in range(100):
            stat = Personatge.roll_stat()
            self.assertGreaterEqual(stat, 3)
            self.assertLessEqual(stat, 18)
    
    def test_crear_aleatori(self):
        """Verificar que crear_aleatori funciona correctament"""
        personatge = Personatge.crear_aleatori(
            nom="Test",
            raca="huma",
            classe="guerrer"
        )
        
        self.assertEqual(personatge.nom, "Test")
        self.assertEqual(personatge.raca, "huma")
        self.assertEqual(personatge.classe, "guerrer")
        
        # Verificar que les estadístiques estan en el rang correcte
        self.assertGreaterEqual(personatge.forca, 3)
        self.assertLessEqual(personatge.forca, 18)
    
    def test_str_method(self):
        """Verificar el mètode __str__"""
        personatge = Personatge.objects.create(
            nom="Legolas",
            raca="elf",
            classe="ranger",
            forca=12, destresa=18, constitucio=14,
            intelligencia=13, saviesa=15, carisma=16
        )
        
        self.assertEqual(
            str(personatge),
            "Legolas - Elf Ranger"
        )

class PersonatgeViewTests(TestCase):
    
    def test_llista_personatges_view(self):
        """Verificar que la vista de llista funciona"""
        response = self.client.get('/personatges/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Personatges Creats")
    
    def test_crear_personatge_manual(self):
        """Verificar creació manual"""
        response = self.client.post('/personatges/crear/', {
            'nom': 'Aragorn',
            'raca': 'huma',
            'classe': 'ranger',
            'forca': 16,
            'destresa': 14,
            'constitucio': 15,
            'intelligencia': 13,
            'saviesa': 14,
            'carisma': 15,
        })
        
        self.assertEqual(response.status_code, 302)  # Redirect
        self.assertEqual(Personatge.objects.count(), 1)
        
        personatge = Personatge.objects.first()
        self.assertEqual(personatge.nom, 'Aragorn')
        self.assertEqual(personatge.forca, 16)
```

**Executar els tests:**

```bash
python manage.py test personatges
```

---

## 📚 Resum Final

### Versió 1 (Manual)
✅ Model amb camps bàsics  
✅ Formulari per entrada manual  
✅ Vista que processa i desa  
✅ Templates HTML amb Bootstrap  

### Versió 2 (Aleatòria)
✅ Funció `roll_stat()` al model  
✅ Checkbox "randomize" al formulari  
✅ Lògica a la vista per generar stats  
✅ JavaScript per millorar UX  

---

## 🎯 Objectius d'Aprenentatge

1. **Models Django**: Crear models amb camps i mètodes personalitzats
2. **Forms Django**: Formularis basats en models amb validació
3. **Views Django**: Processar dades POST i gestionar lògica de negoci
4. **Templates**: Utilitzar herència de templates i Bootstrap
5. **JavaScript**: Millorar la interacció de l'usuari
6. **Testing**: Escriure tests unitaris per validar funcionalitat

---

## 🚀 Següents Passos

1. **Millorar l'Admin de Django**: Registrar el model per gestionar-lo
2. **Afegir més funcionalitats**:
   - Editar personatges existents
   - Eliminar personatges
   - Exportar a PDF
   - Sistema de combat
3. **Millorar el disseny**: Afegir més CSS personalitzat
4. **Deployment**: Desplegar a Heroku o PythonAnywhere

---

**Bones aventures amb Django i D&D! 🎲🐉**
