# 🎲 Referència Ràpida - Code Rolls The Dice

## 📌 Comandos Django Essencials

```bash
# Crear projecte
django-admin startproject dnd_project

# Crear aplicació
python manage.py startapp personatges

# Migracions
python manage.py makemigrations
python manage.py migrate

# Crear superusuari (admin)
python manage.py createsuperuser

# Executar servidor
python manage.py runserver

# Tests
python manage.py test personatges

# Shell interactiu
python manage.py shell
```

---

## 🔧 Configuració Inicial

### 1. Activar Entorn Virtual
```bash
# Crear
python -m venv venv

# Activar (Windows)
venv\Scripts\activate

# Activar (macOS/Linux)
source venv/bin/activate
```

### 2. Instal·lar Django
```bash
pip install django
```

### 3. Afegir App a Settings
```python
# dnd_project/settings.py
INSTALLED_APPS = [
    # ...
    'personatges',  # ← Afegir
]
```

---

## 📂 Estructura de Directoris a Crear

```bash
# Des de personatges/
mkdir -p templates/personatges
```

---

## 🎯 Codi Clau per Copiar

### Model amb roll_stat()
```python
import random

@staticmethod
def roll_stat():
    rolls = [random.randint(1, 6) for _ in range(4)]
    rolls.remove(min(rolls))
    return sum(rolls)
```

### Formulari amb Checkbox
```python
randomize = forms.BooleanField(
    required=False,
    label="🎲 Generar Màgicament",
    help_text="Marca per generar stats automàticament"
)
```

### Vista amb Lògica Condicional
```python
if request.method == 'POST':
    form = PersonatgeForm(request.POST)
    if form.is_valid():
        if form.cleaned_data.get('randomize'):
            personatge = Personatge.crear_aleatori(...)
        else:
            personatge = form.save()
```

### JavaScript per Toggle
```javascript
randomizeCheckbox.addEventListener('change', function() {
    if (this.checked) {
        statInputs.forEach(input => input.disabled = true);
    } else {
        statInputs.forEach(input => input.disabled = false);
    }
});
```

---

## 🗺️ URLs Principals

```python
# personatges/urls.py
urlpatterns = [
    path('', views.llista_personatges, name='llista_personatges'),
    path('crear/', views.crear_personatge, name='crear_personatge'),
]

# dnd_project/urls.py
urlpatterns = [
    path('admin/', admin.site.urls),
    path('personatges/', include('personatges.urls')),
]
```

---

## 📝 Template Tags Essencials

```django
{% extends 'personatges/base.html' %}

{% block title %}Títol{% endblock %}

{% block content %}
    <!-- Contingut -->
{% endblock %}

{% csrf_token %}  <!-- Obligatori en forms POST -->

{% url 'llista_personatges' %}  <!-- URL reversa -->

{{ form.nom }}  <!-- Renderitzar camp de formulari -->

{% if form.nom.errors %}
    {{ form.nom.errors }}
{% endif %}

{% for personatge in personatges %}
    {{ personatge.nom }}
{% endfor %}
```

---

## 🎨 Classes Bootstrap Útils

```html
<!-- Formularis -->
<input class="form-control">
<select class="form-control">
<button class="btn btn-primary">

<!-- Layout -->
<div class="container">
<div class="row">
<div class="col-md-6">

<!-- Alertes -->
<div class="alert alert-success">
<div class="alert alert-danger">

<!-- Cards -->
<div class="card">
    <div class="card-header"></div>
    <div class="card-body"></div>
</div>
```

---

## 🔍 Debugging

### Shell de Django
```python
python manage.py shell

>>> from personatges.models import Personatge
>>> Personatge.objects.all()
>>> p = Personatge.objects.first()
>>> p.nom
>>> Personatge.roll_stat()  # Provar funció
```

### Missatges de Debug
```python
# A views.py
print(f"Randomize: {form.cleaned_data.get('randomize')}")
print(f"Personatge: {personatge}")
```

### Comprovar URLs
```bash
python manage.py show_urls  # Requereix django-extensions
```

---

## ✅ Checklist Pre-Test

- [ ] `settings.py` té 'personatges' a INSTALLED_APPS
- [ ] `dnd_project/urls.py` inclou personatges.urls
- [ ] S'han executat les migracions
- [ ] Els templates estan a `personatges/templates/personatges/`
- [ ] El formulari té el camp `randomize`
- [ ] El model té la funció `roll_stat()`
- [ ] La vista gestiona el checkbox correctament

---

## 🐛 Problemes Comuns

### Error: "No module named personatges"
**Solució:** Afegir 'personatges' a INSTALLED_APPS

### Error: "TemplateDoesNotExist"
**Solució:** Verificar ruta: `personatges/templates/personatges/nom.html`

### Error: "CSRF token missing"
**Solució:** Afegir `{% csrf_token %}` al formulari

### Els camps no es deshabiliten
**Solució:** Verificar que els inputs tenen la classe `stat-input`

### Els stats generats són sempre iguals
**Solució:** Assegurar-se que `import random` és al principi de models.py

---

## 📊 Valors Típics de D&D

| Estadística | Mínim | Màxim | Típic (4d6) |
|-------------|-------|-------|-------------|
| Força | 3 | 18 | 10-13 |
| Destresa | 3 | 18 | 10-13 |
| Constitució | 3 | 18 | 10-13 |
| Intel·ligència | 3 | 18 | 10-13 |
| Saviesa | 3 | 18 | 10-13 |
| Carisma | 3 | 18 | 10-13 |

### Distribució de roll_stat()
- **3-8**: Molt baix (poc comú)
- **9-12**: Normal-baix
- **13-15**: Normal-alt (més comú)
- **16-18**: Excel·lent (menys comú)

---

## 🎓 Conceptes Django

### QuerySet
```python
# Obtenir tots
Personatge.objects.all()

# Filtrar
Personatge.objects.filter(raca='elf')

# Obtenir un
Personatge.objects.get(id=1)

# Crear
Personatge.objects.create(nom='Test', ...)

# Comptar
Personatge.objects.count()
```

### Form Validation
```python
def clean(self):
    cleaned_data = super().clean()
    # Validació personalitzada
    return cleaned_data

def clean_nom(self):
    nom = self.cleaned_data['nom']
    # Validació d'un camp específic
    return nom
```

### Messages Framework
```python
from django.contrib import messages

messages.success(request, "Èxit!")
messages.error(request, "Error!")
messages.warning(request, "Alerta!")
messages.info(request, "Info")
```

---

## 🚀 Millores Futures

### Funcionalitats a Afegir
- [ ] Editar personatges
- [ ] Eliminar personatges
- [ ] Exportar a PDF
- [ ] Sistema de combat
- [ ] Càlcul de modificadors (+/-) segons stats
- [ ] Històric de tirades de daus
- [ ] Múltiples personatges per usuari (amb auth)

### Millores de Codi
- [ ] Usar Class-Based Views (CBVs)
- [ ] Afegir paginació
- [ ] API REST amb Django REST Framework
- [ ] Tests de cobertura >80%
- [ ] Dockeritzar l'aplicació

---

## 📚 Recursos Addicionals

### Documentació
- Django Docs: https://docs.djangoproject.com/
- Bootstrap: https://getbootstrap.com/
- D&D Beyond: https://www.dndbeyond.com/

### Tutorials
- Django Girls: https://tutorial.djangogirls.org/
- Real Python: https://realpython.com/tutorials/django/
- MDN Django: https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django

---

## 🎯 Flow Diagram Complet

```
┌─────────────────────────────────────────┐
│  Usuario visita /personatges/crear/     │
└───────────────┬─────────────────────────┘
                │
                ↓
┌─────────────────────────────────────────┐
│  urls.py → views.crear_personatge()     │
└───────────────┬─────────────────────────┘
                │
                ↓
        ┌───────┴───────┐
        │   GET o POST? │
        └───┬───────┬───┘
            │       │
          GET      POST
            │       │
            ↓       ↓
    ┌───────────┐ ┌──────────────────┐
    │ form buit │ │ form amb dades   │
    └─────┬─────┘ └────────┬─────────┘
          │                │
          │                ↓
          │       ┌─────────────────┐
          │       │ form.is_valid() │
          │       └────┬──────┬─────┘
          │            │      │
          │          SÍ      NO
          │            │      │
          │            ↓      ↓
          │    ┌────────────┐ │
          │    │ randomize? │ │
          │    └─┬────────┬─┘ │
          │      │        │   │
          │    SÍ        NO  │
          │      │        │   │
          │      ↓        ↓   │
          │ crear_     form. │
          │ aleatori() save() │
          │      │        │   │
          │      └───┬────┘   │
          │          ↓        │
          │    ┌────────────┐ │
          │    │  redirect  │ │
          │    └─────┬──────┘ │
          │          │        │
          └──────────┴────────┘
                     │
                     ↓
          ┌─────────────────────┐
          │ Renderitzar template│
          └─────────────────────┘
```

---

## 💡 Tips i Tricks

### Performance
- Usar `select_related()` per ForeignKeys
- Usar `prefetch_related()` per ManyToMany
- Indexar camps que es filtren sovint

### Seguretat
- Sempre usar `{% csrf_token %}`
- Validar totes les entrades
- Usar `get_object_or_404()` per queries individuals
- No exposar informació sensible als templates

### Bones Pràctiques
- Un model per fitxer si és complex
- Mantenir vistes simples (lògica al model)
- Usar noms descriptius (get_*, create_*, list_*)
- Comentar codi complex
- Escriure tests des del principi

---

**Aquesta referència conté tot el necessari per completar l'activitat! 🎲✨**
