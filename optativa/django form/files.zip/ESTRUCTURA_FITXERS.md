# 📂 Estructura de Fitxers - Code Rolls The Dice

## 🗂️ Vista General del Projecte

```
dnd_project/                           # 📁 Directori arrel del projecte Django
│
├── 📁 dnd_project/                    # Configuració principal del projecte
│   ├── __init__.py                    # Fitxer buit per marcar com a paquet Python
│   ├── settings.py                    # ⚙️ CONFIGURACIÓ PRINCIPAL
│   ├── urls.py                        # 🔗 URLS PRINCIPALS DEL PROJECTE
│   ├── asgi.py                        # Configuració ASGI (per async)
│   └── wsgi.py                        # Configuració WSGI (per deployment)
│
├── 📁 personatges/                    # Aplicació de personatges D&D
│   │
│   ├── 📁 migrations/                 # Migracions de la base de dades
│   │   ├── __init__.py
│   │   └── 0001_initial.py           # (Generat automàticament)
│   │
│   ├── 📁 templates/                  # Templates HTML
│   │   └── 📁 personatges/
│   │       ├── base.html             # 🎨 TEMPLATE BASE
│   │       ├── crear_personatge.html # 📝 FORMULARI DE CREACIÓ
│   │       └── llista_personatges.html # 📋 LLISTA DE PERSONATGES
│   │
│   ├── __init__.py
│   ├── admin.py                      # 👑 Registre per l'Admin de Django
│   ├── apps.py                       # Configuració de l'app
│   ├── models.py                     # 🎲 MODEL PERSONATGE + roll_stat()
│   ├── forms.py                      # 📄 FORMULARI + checkbox randomize
│   ├── views.py                      # 🧠 LÒGICA DE LES VISTES
│   ├── urls.py                       # 🔗 URLS DE L'APP (crear-lo)
│   └── tests.py                      # ✅ Tests unitaris
│
├── db.sqlite3                        # 💾 Base de dades SQLite
├── manage.py                         # 🛠️ Script de gestió de Django
└── requirements.txt                  # 📦 Dependències del projecte
```

---

## 📝 Fitxers a Crear o Modificar

### 1️⃣ Configuració del Projecte

#### `dnd_project/settings.py`
**Què fer:** Afegir l'aplicació `personatges` a `INSTALLED_APPS`

```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'personatges',  # ← AFEGIR AQUESTA LÍNIA
]
```

---

#### `dnd_project/urls.py`
**Què fer:** Incloure les URLs de l'aplicació `personatges`

```python
from django.contrib import admin
from django.urls import path, include  # ← Importar include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('personatges/', include('personatges.urls')),  # ← AFEGIR
]
```

---

### 2️⃣ Aplicació `personatges`

#### `personatges/models.py` ✨ PRINCIPAL
**Què conté:**
- Model `Personatge` amb tots els camps (nom, raça, classe, stats)
- Funció `roll_stat()` per generar estadístiques aleatòries (4d6)
- Funció `crear_aleatori()` per crear personatges amb stats aleatòries

**Funcionalitats clau:**
```python
@staticmethod
def roll_stat():
    """Tira 4d6, descarta el més baix"""
    rolls = [random.randint(1, 6) for _ in range(4)]
    rolls.remove(min(rolls))
    return sum(rolls)
```

---

#### `personatges/forms.py` ✨ PRINCIPAL
**Què conté:**
- Formulari basat en el model `Personatge`
- Camp checkbox `randomize` per activar la generació aleatòria
- Widgets personalitzats amb Bootstrap
- Validació personalitzada (stats entre 3-18)

**Camp clau:**
```python
randomize = forms.BooleanField(
    required=False,
    label="🎲 Generar Màgicament",
    help_text="Marca per generar stats automàticament (4d6)"
)
```

---

#### `personatges/views.py` ✨ PRINCIPAL
**Què conté:**
- Vista `crear_personatge()` que gestiona la creació (manual o aleatòria)
- Vista `llista_personatges()` per mostrar tots els personatges
- Lògica per detectar si el checkbox `randomize` està marcat

**Lògica clau:**
```python
if randomize:
    personatge = Personatge.crear_aleatori(...)
else:
    personatge = form.save()
```

---

#### `personatges/urls.py` 🆕 CREAR
**Què conté:**
- Rutes de l'aplicació (llista i crear)

```python
from django.urls import path
from . import views

urlpatterns = [
    path('', views.llista_personatges, name='llista_personatges'),
    path('crear/', views.crear_personatge, name='crear_personatge'),
]
```

---

#### `personatges/admin.py` (Opcional)
**Què fer:** Registrar el model per gestionar-lo des de l'admin

```python
from django.contrib import admin
from .models import Personatge

@admin.register(Personatge)
class PersonatgeAdmin(admin.ModelAdmin):
    list_display = ['nom', 'raca', 'classe', 'forca', 'destresa', 
                    'constitucio', 'intelligencia', 'saviesa', 'carisma', 'creat_el']
    list_filter = ['raca', 'classe']
    search_fields = ['nom']
```

---

### 3️⃣ Templates HTML

#### `personatges/templates/personatges/base.html` 🆕 CREAR
**Què conté:**
- Template base amb Bootstrap
- Estructura HTML comuna (head, body, container)
- Sistema de missatges de Django
- Estils CSS personalitzats

---

#### `personatges/templates/personatges/crear_personatge.html` 🆕 CREAR
**Què conté:**
- Formulari per crear personatges
- Checkbox "Generar Màgicament"
- Camps per nom, raça, classe i estadístiques
- JavaScript per amagar/mostrar camps segons el checkbox
- Validació HTML5

**JavaScript clau:**
```javascript
randomizeCheckbox.addEventListener('change', function() {
    if (this.checked) {
        // Deshabilitar camps d'estadístiques
        statInputs.forEach(input => input.disabled = true);
    } else {
        // Habilitar camps d'estadístiques
        statInputs.forEach(input => input.disabled = false);
    }
});
```

---

#### `personatges/templates/personatges/llista_personatges.html` 🆕 CREAR
**Què conté:**
- Llista de tots els personatges creats
- Cards amb informació de cada personatge
- Botó per crear un nou personatge
- Missatge si no hi ha personatges

---

### 4️⃣ Fitxers Addicionals

#### `requirements.txt` 🆕 CREAR
```
Django>=5.0,<6.0
```

#### `personatges/tests.py`
**Què conté:**
- Tests per `roll_stat()` (verificar rang 3-18)
- Tests per `crear_aleatori()`
- Tests per les vistes
- Tests del mètode `__str__`

---

## 🎯 Fitxers Principals de cada Versió

### Versió 1: Creació Manual

| Fitxer | Què fa |
|--------|--------|
| `models.py` | Defineix el model `Personatge` amb camps bàsics |
| `forms.py` | Formulari per introduir dades manualment |
| `views.py` | Vista que processa el formulari i desa a la BD |
| `crear_personatge.html` | Template amb el formulari HTML |

---

### Versió 2: Generació Aleatòria

| Fitxer | Què s'afegeix/modifica |
|--------|------------------------|
| `models.py` | ✅ Funció `roll_stat()` + `crear_aleatori()` |
| `forms.py` | ✅ Camp `randomize` (checkbox) |
| `views.py` | ✅ Lògica per detectar `randomize` i generar stats |
| `crear_personatge.html` | ✅ Checkbox + JavaScript per amagar camps |

---

## 🚀 Ordre de Creació dels Fitxers

### Pas 1: Estructura Base
1. Crear projecte: `django-admin startproject dnd_project`
2. Crear app: `python manage.py startapp personatges`
3. Afegir app a `settings.py`

### Pas 2: Models i Base de Dades
4. Crear `personatges/models.py` (Model Personatge)
5. `python manage.py makemigrations`
6. `python manage.py migrate`

### Pas 3: Formularis
7. Crear `personatges/forms.py` (PersonatgeForm)

### Pas 4: Vistes
8. Crear vistes a `personatges/views.py`

### Pas 5: URLs
9. Crear `personatges/urls.py`
10. Modificar `dnd_project/urls.py`

### Pas 6: Templates
11. Crear directori `personatges/templates/personatges/`
12. Crear `base.html`
13. Crear `crear_personatge.html`
14. Crear `llista_personatges.html`

### Pas 7: Admin (Opcional)
15. Configurar `personatges/admin.py`
16. Crear superusuari: `python manage.py createsuperuser`

### Pas 8: Tests
17. Escriure tests a `personatges/tests.py`
18. Executar: `python manage.py test`

---

## 📊 Mapa de Dependències

```
settings.py
    ↓
models.py (Personatge, roll_stat, crear_aleatori)
    ↓
forms.py (PersonatgeForm amb checkbox randomize)
    ↓
views.py (crear_personatge, llista_personatges)
    ↓
urls.py (rutes de l'app)
    ↓
templates/ (HTML amb formularis i llistes)
```

---

## 🎨 Arquitectura de l'Aplicació

```
┌─────────────┐
│   Usuario   │
└──────┬──────┘
       │
       ↓ (HTTP Request)
┌──────────────────┐
│   urls.py        │ ← Rutes URL
└──────┬───────────┘
       │
       ↓
┌──────────────────┐
│   views.py       │ ← Lògica de negoci
└──────┬───────────┘
       │
       ↓
┌──────────────────┐
│   forms.py       │ ← Validació de dades
└──────┬───────────┘
       │
       ↓
┌──────────────────┐
│   models.py      │ ← Base de dades
└──────┬───────────┘
       │
       ↓ (Context)
┌──────────────────┐
│   templates/     │ ← Renderització HTML
└──────┬───────────┘
       │
       ↓ (HTTP Response)
┌─────────────┐
│   Usuario   │
└─────────────┘
```

---

## ✅ Checklist de Fitxers

### Configuració
- [ ] `dnd_project/settings.py` (modificar)
- [ ] `dnd_project/urls.py` (modificar)
- [ ] `requirements.txt` (crear)

### Aplicació
- [ ] `personatges/models.py` (crear)
- [ ] `personatges/forms.py` (crear)
- [ ] `personatges/views.py` (crear)
- [ ] `personatges/urls.py` (crear)
- [ ] `personatges/admin.py` (modificar - opcional)
- [ ] `personatges/tests.py` (modificar - opcional)

### Templates
- [ ] `personatges/templates/personatges/base.html` (crear)
- [ ] `personatges/templates/personatges/crear_personatge.html` (crear)
- [ ] `personatges/templates/personatges/llista_personatges.html` (crear)

### Migracions
- [ ] `python manage.py makemigrations`
- [ ] `python manage.py migrate`

---

## 🔍 On Buscar Cada Cosa

| Vull fer... | On ho trobo |
|-------------|-------------|
| Afegir un camp nou al personatge | `models.py` → classe `Personatge` |
| Canviar les opcions de raça/classe | `models.py` → constants `RACES` / `CLASSES` |
| Modificar la lògica de 4d6 | `models.py` → funció `roll_stat()` |
| Afegir un nou camp al formulari | `forms.py` → classe `Meta` → `fields` |
| Canviar la validació | `forms.py` → funció `clean()` |
| Modificar què passa quan es crea | `views.py` → funció `crear_personatge()` |
| Canviar el disseny del formulari | `crear_personatge.html` |
| Afegir més funcionalitats JS | `crear_personatge.html` → `<script>` |
| Canviar l'estil visual | `base.html` → `<style>` |
| Afegir una nova pàgina | `urls.py` + nova vista + nou template |

---

## 🎓 Conceptes Clau

### MVC (Model-View-Controller) en Django
- **Model** (`models.py`): Dades i lògica de negoci
- **View** (`views.py`): Controlador (lògica de l'aplicació)
- **Template** (`templates/`): Vista (presentació HTML)

### Flux de Dades
1. **Request** → `urls.py` decideix quina vista cridar
2. **Vista** → `views.py` processa la petició
3. **Formulari** → `forms.py` valida les dades (si és POST)
4. **Model** → `models.py` guarda/recupera de la BD
5. **Template** → Renderitza HTML amb les dades
6. **Response** → Retorna HTML al navegador

---

## 🎯 Diferències entre Versió 1 i 2

| Aspecte | Versió 1 | Versió 2 |
|---------|----------|----------|
| **models.py** | Model bàsic | + `roll_stat()` + `crear_aleatori()` |
| **forms.py** | Formulari simple | + camp `randomize` |
| **views.py** | `form.save()` directe | Condicional segons `randomize` |
| **template** | Formulari HTML | + Checkbox + JavaScript |
| **Experiència** | Manual total | Opció automàtica |

---

**Aquesta estructura és escalable i segueix les millors pràctiques de Django! 🚀**
